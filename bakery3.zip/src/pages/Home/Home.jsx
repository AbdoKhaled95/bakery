import React from "react";
import HomeBanner from "../../components/Banner/HomeBanner";

const Home = () => {
  return (
    <>
      <HomeBanner />
    </>
  );
};

export default Home;
