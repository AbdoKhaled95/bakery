const darkPalette = {
  mode: "dark",
  secondary: {
    main: "#686868",
  },
};
export default darkPalette;
