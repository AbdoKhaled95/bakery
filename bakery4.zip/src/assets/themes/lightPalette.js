const lightPalette = {
  mode: "light",
  primary: {
    main: "#8e7754",
  },
  secondary: {
    main: "#686868",
  },
};
export default lightPalette;
