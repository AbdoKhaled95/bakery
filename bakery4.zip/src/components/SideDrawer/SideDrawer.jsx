import { Drawer, IconButton, Box, Container, Typography } from "@mui/material";
import React, { useState } from "react";
import SettingsIcon from "@mui/icons-material/Settings";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
const drawerWidth = 290;
const SideDrawer = () => {
  const [anchor, setAnchor] = useState("right");
  const [position, setPosition] = useState(0);
  const [isOpend, setIsOpend] = useState(false);

  const drawerOpen = () => {
    if (isOpend) {
      setPosition(0);
      setIsOpend(false);
    } else {
      setPosition(drawerWidth - 1);
      setIsOpend(true);
    }
  };
  return (
    <>
      <Box
        sx={{
          px: 0.5,
          borderRadius: "4px 0 0 4px",
          bgcolor: "white",
          transition: "all 225ms",
          position: "fixed",
          top: "200px",
          right: position,
          zIndex: 1600,
          display: "flex",
          flexDirection: "column",
          gap: 0.5,
        }}
      >
        <IconButton
          onClick={() => drawerOpen()}
          sx={{ ":hover": { bgcolor: "transparent", color: "primary.main" } }}
        >
          <SettingsIcon fontSize="small" />
        </IconButton>
        <IconButton
          sx={{ ":hover": { bgcolor: "transparent", color: "primary.main" } }}
        >
          <ShoppingCartIcon fontSize="small" />
        </IconButton>
      </Box>

      <Drawer
        variant="persistent"
        open={isOpend}
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          bgcolor: "red",

          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
            boxShadow: "0 0 7px rgba(0,0,0,0.15)",
          },
        }}
        anchor={anchor}
      >
        <Container disableGutters maxWidth="xs" sx={{ m: "24px" }}>
          <Typography>test</Typography>
        </Container>
      </Drawer>
    </>
  );
};

export default SideDrawer;
